# Day05 作业布置

## 一. 完成上课所有的代码练习



## 二.什么是ECharts? ECharts 应用场景有哪些?



## 三.ECharts 渲染原理



## 四.ECharts常用的组件有哪些



## 五.绘制Echarts的地图的步骤



## 六.如何制作响应式图表

