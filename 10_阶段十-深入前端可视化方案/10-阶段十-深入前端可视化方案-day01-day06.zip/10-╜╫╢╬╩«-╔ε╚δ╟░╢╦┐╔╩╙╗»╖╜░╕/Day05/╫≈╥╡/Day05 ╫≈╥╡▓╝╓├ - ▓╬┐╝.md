# Day05 作业布置

## 一. 完成上课所有的代码练习



## 二.什么是ECharts? ECharts 应用场景有哪些?

什么是ECharts

- ECharts （全称 EnterpriseCharts ）是企业级数据图表。官方的解释是：一个基于 JavaScript 的开源可视化图表库。

- ECharts可以流畅的运行在PC和移动设备上，兼容当前绝大部分浏览器（IE6/7/8/9/10/11，chrome，firefox，Safari等）。

- ECharts底层依赖轻量级的ZRender图形库，可提供直观，生动，可交互，可高度个性化定制的数据可视化图表。

  

ECharts 应用场景:

- 智慧城市、园区、航运、公安、机房、监所、电力、物业、应急管理等多个领域的数据可视化展示

  

## 三.ECharts 渲染原理

- ECharts 最开始时一直都是使用 Canvas 绘制图表。直到 [ECharts v4.0](https://github.com/apache/echarts/releases) 版本，才发布支持 SVG 渲染器。

- SVG 和 Canvas 这两种使用方式在技术上是有很大的差异的，EChart能够做到同时支持，主要归功于 ECharts 底层库 [ZRender](https://github.com/ecomfe/zrender) 的抽象和实现。

- [ZRender](https://github.com/ecomfe/zrender) 是二维轻量级的绘图引擎，它提供 Canvas、SVG、VML 等多种渲染方式。

- 因此，Echarts 可以轻松的互换SVG 渲染器 和 Canvas 渲染器。切换渲染器只须在初始化图表时设置 [renderer ](https://echarts.apache.org/api.html)[参数](https://echarts.apache.org/api.html) 为canvas或svg即可。

## 四.ECharts常用的组件有哪些

- grid 选项 ：直角坐标系内绘图区域

- yAxis 选项 ：直角坐标系 grid 中的 y 轴

- xAxis 选项 ：直角坐标系 grid 中的 x 轴

- title **：**图表的标题

- legend：图例，展现了不同系列的标记、颜色和名字

- tooltip：提示框

- toolbox：工具栏，提供操作图表的工具

- series：系列，配置系列图表的类型和图形信息数据

- visualMap：视觉映射，可以将数据值映射到图形的形状、大小、颜色等

- geo：地理坐标系组件。用于地图的绘制，支持在地理坐标系上绘制[散点图](https://echarts.apache.org/zh/option.html)，[线集](https://echarts.apache.org/zh/option.html)。



## 五.绘制Echarts的地图的步骤



ECharts绘制地图步骤（方式一）：

- 1.拿到GeoJSON数据

- 2.注册对应的地图的GeoJSON数据（调用setOption前注册）

- 3.配置geo选项。



ECharts绘制地图步骤（方式二）：

- 1.拿到GeoJSON数据

- 2.注册对应的地图的GeoJSON数据（调用setOption前注册）

- 3.配置map series。



## 六.如何制作响应式图表

响应式图片的实现步骤：

- 1.图表只设置高度，宽度设置为100% 或 不设置。

- 2.监听窗口的resize事件，即监听窗口尺寸的变化（需节流）。

- 3.当窗口大小改变时，然后调用 [echartsInstance.resize](https://echarts.apache.org/api.html) 改变图表的大小。