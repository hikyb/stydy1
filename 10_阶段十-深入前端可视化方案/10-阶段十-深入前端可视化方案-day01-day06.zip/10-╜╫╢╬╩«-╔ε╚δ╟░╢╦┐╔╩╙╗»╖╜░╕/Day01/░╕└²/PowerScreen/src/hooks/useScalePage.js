import { onMounted, onUnmounted } from "vue";
import _ from "lodash";

export default function useScalePage(option) {
  // 组件挂载完成后，开始监听屏幕大小的变化
  let resizeFunc = _.throttle(function () {
    // console.log("xx");
    triggerScale();
  }, 100);

  onMounted(function () {
    // 先执行一次
    triggerScale();
    window.addEventListener("resize", resizeFunc);
  });

  onUnmounted(function () {
    window.removeEventListener("resize", resizeFunc);
  });

  function triggerScale() {
    var targetX = option.targetX || 1920;
    var targetY = option.targetY || 1080;
    var targetRatio = option.targetRatio || 16 / 9;
    var x = document.documentElement.clientWidth || document.body.clientHeight;
    var y = document.documentElement.clientHeight || document.body.clientHeight;
    var bodyEl = document.querySelector(option.selector || "body");

    let scale = x / targetX; // 默认根据x轴缩放

    if (option.mode === "x") {
      bodyEl.setAttribute("style", `transform: scale(${scale})`);
      return;
    }

    if (option.mode === "y") {
      scale = y / targetY; // 根据Y轴缩放
      bodyEl.setAttribute(
        "style",
        `transform: scale(${scale}) translateX(-${targetX / 2}px);left:50%`
      );
      return;
    }

    let curRatio = x / y;
    if (curRatio > targetRatio) {
      scale = y / targetY; // 根据Y轴缩放
      bodyEl.setAttribute(
        "style",
        `transform: scale(${scale}) translateX(-${targetX / 2}px);left:50%`
      );
    } else {
      // 根据X轴缩放
      bodyEl.setAttribute("style", `transform: scale(${scale})`);
    }
  }
}
