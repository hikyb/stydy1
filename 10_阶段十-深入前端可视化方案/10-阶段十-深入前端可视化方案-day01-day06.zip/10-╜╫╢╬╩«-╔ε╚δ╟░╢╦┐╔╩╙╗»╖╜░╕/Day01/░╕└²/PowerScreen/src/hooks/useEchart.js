import { ref, onMounted, onUnmounted } from "vue";
import * as echarts from "echarts";

import _ from "lodash";

export default function useEchart(elementRef) {
  const echartInstance = echarts.init(elementRef, null, { renderer: "svg" });

  function setOption(option) {
    echartInstance.setOption(option);
  }

  function resizeEchart() {
    echartInstance.resize();
  }
  let resizeFunc = _.throttle(() => {
    console.log("0");
    echartInstance.resize();
  }, 100);

  window.addEventListener("resize", resizeFunc);

  onUnmounted(function () {
    window.removeEventListener("resize", resizeFunc);
  });

  return {
    echartInstance,
    setOption,
    resizeEchart,
  };
}
