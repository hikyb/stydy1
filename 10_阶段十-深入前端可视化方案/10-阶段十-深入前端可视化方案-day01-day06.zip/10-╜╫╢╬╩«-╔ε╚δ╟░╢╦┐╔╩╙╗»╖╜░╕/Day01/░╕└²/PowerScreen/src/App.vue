<template>
  <RouterView />
</template>

<script setup>
import { RouterView } from "vue-router";
import useScalePage from "./hooks/useScalePage";

// 设计稿大小
let option = {
  mode: "auto", // 缩放模式 auto x y
  selector: "body",
  targetX: 1920,
  targetY: 1080,
  targetRatio: 16 / 9,
};
// 大屏适配
useScalePage(option);
</script>

<style scoped></style>
