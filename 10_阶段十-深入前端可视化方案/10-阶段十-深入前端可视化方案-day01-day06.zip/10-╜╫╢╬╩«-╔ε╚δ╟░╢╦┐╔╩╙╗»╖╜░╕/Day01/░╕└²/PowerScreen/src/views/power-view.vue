<template>
  <main class="screen-bg">
    <div class="header"></div>

    <div class="left-top">
      <pie-echart id="left-top-pie"></pie-echart>
    </div>
    <div class="left-bottom">
      <line-echart></line-echart>
    </div>

    <div class="right-top">
      <right-top-panel></right-top-panel>
    </div>
    <div class="right-center">
      <bar-echart></bar-echart>
    </div>
    <div class="right-bottom">
      <right-bottom-svg></right-bottom-svg>
    </div>

    <div class="center">
      <center-svg></center-svg>
    </div>

    <div class="bottom">
      <bottom-panel></bottom-panel>
    </div>
  </main>
</template>
<script setup>
import BarEchart from "../components/bar-echart.vue";
import BottomPanel from "../components/bottom-panel.vue";
import CenterSvg from "../components/center-svg.vue";
import LineEchart from "../components/line-echart.vue";
import PieEchart from "../components/pie-echart.vue";
import RightBottomSvg from "../components/right-bottom-svg.vue";
import RightTopPanel from "../components/right-top-panel.vue";
</script>
<style scoped lang="scss">
.screen-bg {
  /* 定位 */
  position: absolute;
  width: 100%;
  height: 100%;
  /* 背景 */
  /* border: 1px solid red; */
  background-color: #070a3c;
  background-image: url(../assets/images/bg.png);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.header {
  /* 定位 */
  position: absolute;
  top: 21px;
  height: 56px;
  width: 100%;
  /* 背景 */
  /* background-color: red; */
  background-image: url(../assets/images/bg_header.svg);
  background-repeat: no-repeat;
  background-size: cover;
}

.left-top {
  /* 定位 */
  position: absolute;
  left: 16px;
  top: 116px;
  width: 536px;
  height: 443px;
  /* 背景 */
  /* border:  1px solid red; */
  background-image: url(../assets/images/bg_left-top.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.left-bottom {
  /* 定位 */
  position: absolute;
  left: 16px;
  bottom: 49px;
  width: 536px;
  height: 443px;
  /* 背景 */
  /* border:  1px solid red; */
  background-image: url(../assets/images/bg_left_bottom.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

.right-top {
  position: absolute;
  right: 17px;
  top: 96px;
  width: 519px;
  height: 327px;
  /* border:  1px solid red; */
  background-image: url(../assets/images/bg_right_top.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.right-center {
  position: absolute;
  right: 17px;
  top: 443px;
  width: 519px;
  height: 327px;
  /* border:  1px solid red; */
  background-image: url(../assets/images/bg_right_center.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.right-bottom {
  position: absolute;
  right: 17px;
  bottom: 49px;
  width: 519px;
  height: 242px;

  display: flex;
  justify-content: center;
  align-items: center;
  /* border:  1px solid red; */
  background-image: url(../assets/images/bg_right_bottom.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

.center {
  position: absolute;
  right: 540px;
  bottom: 272px;
  width: 823px;
  height: 710px;
  /* border: 5px solid pink; */
}

.bottom {
  position: absolute;
  right: 540px;
  bottom: 49px;
  width: 823px;
  height: 209px;
  /* border:  1px solid green; */
  background-image: url(../assets/images/bg_bottom.svg);
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

/*
 防烟花特效
*/

.center .lingxA {
  opacity: 0;
  animation: lingxA 2s linear infinite;
}
.center .lingxB {
  opacity: 0;
  animation: lingxB 2.2s linear infinite;
}
.center .lingxC {
  opacity: 0;
  animation: lingxC 1.7s linear infinite;
}
.center .lingxD {
  opacity: 0;
  animation: lingxC 2.7s linear infinite;
}
.center .lingxE {
  opacity: 0;
  animation: lingxB 1.2s linear infinite;
}
.center .lingxF {
  opacity: 0;
  animation: lingxA 1.4s linear infinite;
}

/* 向上移动的烟花 */
@keyframes lingxA {
  from {
    transform: translateY(0px);
    opacity: 1;
  }
  60% {
    opacity: 1;
  }
  to {
    transform: translateY(-160px);
    opacity: 0;
  }
}

@keyframes lingxB {
  from {
    transform: translateY(0px);
    opacity: 1;
  }

  40% {
    opacity: 1;
  }

  60%,
  to {
    transform: translateY(-120px);
    opacity: 0;
  }
}

@keyframes lingxC {
  from {
    transform: translateY(0px);
    opacity: 1;
  }

  30% {
    opacity: 1;
  }

  50%,
  to {
    transform: translateY(-90px);
    opacity: 0;
  }
}
</style>
