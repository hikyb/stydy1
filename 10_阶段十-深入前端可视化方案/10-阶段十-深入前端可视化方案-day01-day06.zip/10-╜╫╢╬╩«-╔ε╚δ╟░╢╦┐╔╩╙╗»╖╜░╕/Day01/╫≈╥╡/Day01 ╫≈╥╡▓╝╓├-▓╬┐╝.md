# Day01 作业布置

## 一. 完成上课所有的代码练习

- 重点
  - 掌握3D坐标系的旋转
  - 2.5D动画的样式调整

## 二.可视化技术解决方案有哪些?

- 底层图形引擎
  - Skia
  - OpenGl
- W3C提供
  - CSS3
  - Canvas
  - WebGl
- 第三方的可视化库
  - ZRnder
  - Echarts图表
  - Highcharts
  - D3.js
  - Three.js
  - 百度地图等
- 低代码平台
  - DataV ---> 阿里云
  - 腾讯云图
  - 网易有数

## 三.说说CSS中元素的坐标系

- x轴
  - 默认以视口左上角为原点
  - 向右方向为正
- y轴
  - 默认以视口左上角为原点
  - 向下方向为正
- z轴
  - 默认以视口左上角为原点
  - 正对屏幕的方向为正

## 四.3D的动画函数有哪些?

- translate3D()   translateZ()

- rotate3D()  rotateZ()

- scale3D()  scaleZ()

  

## 五.CSS3的动画如何优化?

- 创建新的渲染层
- 启用GPU加速
- 善用CSS3形变动画

- 少用渐变和高斯模糊
- 当不需要动画时，及时关闭动画