# Day03 作业布置

## 一. 完成上课所有的代码练习

- 重点
  - 创建svg的方式
  - svg的使用方式
  - svg的坐标系
  - viewPort和viewBox
  - 如何绘制基本的图形
  - 绘制图片和文本
  - svg的组合和复用
  - 填充颜色和描边的方式
  - 用CSS来填充和描边的方式

## 二.什么是SVG?  SVG有哪些优缺点 ?

- SVG全称Scalable Vector Graphics,即可缩放矢量图形
  - 基于XML格式的矢量图,主要用于定义二维图形,支持交互和动画
  - 可以用文本编辑器或者矢量图形编辑器创建和编辑,并且可以直接在浏览器显示
- 优点
  - 扩展性好,支持许多设备和浏览器,放大不会失真
  - 灵活
    - SVG可以直接使用JS和CSS进行操作
    - 可以结合其它的语言和技术一起使用,比如CSS,JS,HTML,SMIL
  - 可以进行动画处理
  - 轻量级
    - SVG图像质量是PNG的多倍
  - 可打印
    - 支持任何分辨率,不会失真
  - 利于SEO
    - 可以被搜索引擎检索
  - 可以压缩
    - 支持压缩
  - 容易编辑
- 缺点
  - 不适用于高清图片制作
  - SVG图像变得复杂时,加载速度比较慢
  - 不完全跨平台
    - 不适用于IE8及更低级版本的旧浏览器

## 三.SVG和Canvas的区别?  分别有哪些应用场景?

- SVG和Canvas的区别
  - 扩展性
    - svg是矢量图,放大不会失真
    - canvas是光栅图,由像素点构成,放大后会失真
  - 渲染能力
    - 当svg变得复杂时,它的渲染速度会变得很慢
    - Canvas提供了高性能的渲染和更快的图形处理能力
  - 灵活度
    - SVG可以通过JS和CSS进行修改,用SVG来创建动画非常方便
    - Canvas只能通过JS,创建动画要一帧帧设计
  - 使用场景
    - Cavas主要用于游戏开发,绘制图形,复杂照片合成
    - SVG主要用于显示矢量徽标,图标的显示
- SVG的应用场景
  - 显示矢量徽标,图标的显示
  - 在多种屏幕尺寸上显示,矢量图形,放大缩小不会失真
  - 创建简单的动画
  - 制作各种图表,大屏可视化页面开发

## 四.请写出SVG1.0 和 SVG2.0的文档结构

- SVG1.0的文档结构

```css
<?xml version="1.0" encoding="utf-8" standalone="no" ?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">

<!--
    version 版本
    baseProfile: 正常渲染svg内容时所需要最小svg语言概述
                 full: 正常的svg语言概述
                 basic: 基本的svg语言概述
                 tiny: 轻量级svg语言概述
    xmlns: 指定svg元素 命名空间的概念,避免标签的冲突

-->
<svg version='1.0' baseProfile="full" width="100" height="100" xmlns="http://www.w3.org/2000/svg">
    <rect  x="0" y="0" width="100" height="100"></rect>
    <title>我是一个标题</title>
</svg>
```

- SVG2.0版本的文档结构

```css
<svg
  width='400'
  height='400'
>
  <rect x='10' y='10' height='100' width='100'></rect>
</svg>
```

## 五. viewport 和 viewBox 分别是什么?

- viewport
  - SVG可见的区域,或者说是SVG画布的大小
  - 有width和height属性
- viewBox
  -  定义用户坐标系中的位置和尺寸  ---> 该区域通常会被缩放填充视口
  - 可以理解为指定用户坐标系的大小,我们绘制的SVG图形都是绘制到该区域中的
  - 用户坐标系可以比视口坐标系更小或更大
- tips
  - 如果用户坐标系和视口坐标系有相同的高宽比,viewBox的区域会被拉升以填充视口区域

## 六.symbol元素和defs元素有什么区别?

- symobl元素和defs元素的区别
  - 相同点
    - 定义我们想要的复用元素
    - 在symbol元素或defs定义的元素不会直接显示
  - 不同点
    - defs没有专有属性,使用时通常也不需要添加任何属性
    - symbol元素有自己的专有元素
      - viewBox
        - 定义当前的symbol元素的视图框
      - x/y
        - symbol元素的坐标,默认0,0
      - width/height
        - symbol元素的宽度和高度

## 七.SVG样式有几种编写方式? 优先级别是什么?

- 方式一
  - svg元素的行内样式stye
  - 优先级别最高
- 方式二
  - defs中使用style样式标签编写的样式
  - 优先级第二
- 方式三
  - 将样式写在Heade中的style标签中
  - 优先级第三
- 方式四
  - svg元素自身的属性
  - 优先级最低